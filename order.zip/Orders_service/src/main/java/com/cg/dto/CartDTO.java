package com.cg.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class CartDTO {

	 private Integer id;

	    private String name;
	    private double price;
	    private Integer quantity;
	    
	    private Integer customerId;
}
