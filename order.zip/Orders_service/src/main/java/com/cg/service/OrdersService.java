package com.cg.service;

import java.util.List;

import com.cg.dto.OrdersDTO;
import com.cg.entity.Orders;
import com.cg.exception.OrderNotFoundException;

public interface OrdersService {
	    OrdersDTO placeOrder(OrdersDTO orderDTO);
	    OrdersDTO getOrderById(int orderId) throws OrderNotFoundException;
		Orders saveAddress(Orders order) throws OrderNotFoundException;
}
