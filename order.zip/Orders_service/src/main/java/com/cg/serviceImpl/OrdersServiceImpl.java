package com.cg.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.CartService;
import com.cg.client.CustomerService;
import com.cg.dto.OrdersDTO;
import com.cg.entity.Orders;
import com.cg.entity.Status;
import com.cg.exception.OrderNotFoundException;
import com.cg.repository.OrdersRepository;
import com.cg.service.OrdersService;

@Service
public class OrdersServiceImpl implements OrdersService {

    @Autowired
    private CartService cartService;

    @Autowired
    private OrdersRepository ordersRepository;

    @Autowired
    private CustomerService customerService;

    @Override
    public OrdersDTO placeOrder(OrdersDTO orderDTO) {
        Orders order = new Orders();
        order.setFlatNo(orderDTO.getFlatNo());
        order.setBuildingName(orderDTO.getBuildingName());
        order.setArea(orderDTO.getArea());
        order.setPincode(orderDTO.getPincode());
        order.setDate(LocalDateTime.now());
        order.setStatus(Status.PENDING); // Set initial status

        Orders savedOrder = ordersRepository.save(order);
        return convertToDTO(savedOrder);
    }

    @Override
    public OrdersDTO getOrderById(int orderId) throws OrderNotFoundException {
        return ordersRepository.findById(orderId)
                .map(this::convertToDTO)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with ID: " + orderId));
    }

    private OrdersDTO convertToDTO(Orders order) {
        OrdersDTO dto = new OrdersDTO();
        dto.setOrderId(order.getOrderId());
        dto.setFlatNo(order.getFlatNo());
        dto.setBuildingName(order.getBuildingName());
        dto.setArea(order.getArea());
        dto.setPincode(order.getPincode());
        dto.setDate(order.getDate());
        dto.setStatus(order.getStatus());
        return dto;
    }

	@Override
	public Orders saveAddress(Orders order) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		Orders ord1 = ordersRepository.save(order);
		
		return ord1;
	}

}
