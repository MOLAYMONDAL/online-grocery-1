package com.cg.exception;

public class OrderNotFoundException extends Exception{
	
	public OrderNotFoundException(String string) {
		super(string);
	}

	public OrderNotFoundException() {

	super();
	}

}
