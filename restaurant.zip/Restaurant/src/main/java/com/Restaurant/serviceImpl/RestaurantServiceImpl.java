package com.Restaurant.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Restaurant.entity.Restaurant;
import com.Restaurant.exception.RestaurantNotFoundException;
import com.Restaurant.repositary.RestaurantRepository;
import com.Restaurant.service.RestaurantService;

@Service
public class RestaurantServiceImpl implements RestaurantService {

    private static final Logger logger = LoggerFactory.getLogger(RestaurantServiceImpl.class);

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Override
    public Restaurant addRestaurant(Restaurant restaurant) {
        return restaurantRepository.save(restaurant);
    }

    @Override
    public Restaurant updateRestaurant(int id, Restaurant restaurant) throws RestaurantNotFoundException {
        Restaurant existingRestaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant with ID " + id + " not found"));

        existingRestaurant.setName(restaurant.getName());
        existingRestaurant.setAddress(restaurant.getAddress());
        existingRestaurant.setDescription(restaurant.getDescription());
        existingRestaurant.setAdminId(restaurant.getAdminId());

        logger.info("Updating restaurant with ID: {}", id);
        return restaurantRepository.save(existingRestaurant);
    }

    @Override
    public String deleteRestaurant(int id) throws RestaurantNotFoundException {
        Restaurant restaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant with ID " + id + " not found"));
        
        restaurantRepository.delete(restaurant);
        logger.info("Deleted restaurant with ID: {}", id);
        return "Restaurant with ID " + id + " has been deleted";
    }

    @Override
    public Restaurant getRestaurantByName(String name) {
        Restaurant restaurant = restaurantRepository.findByName(name);
        if (restaurant == null) {
            logger.warn("Restaurant with name {} not found", name);
            throw new RestaurantNotFoundException("Restaurant with name " + name + " not found");
        }
        return restaurant;
    }

    @Override
    public Restaurant getRestaurantById(int id) throws RestaurantNotFoundException {
        return restaurantRepository.findById(id)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant with ID " + id + " not found"));
    }

    @Override
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }
}
