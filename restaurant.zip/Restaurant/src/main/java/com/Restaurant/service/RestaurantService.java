package com.Restaurant.service;

import java.util.List;

import com.Restaurant.entity.Restaurant;
import com.Restaurant.exception.RestaurantNotFoundException;

public interface RestaurantService {
    Restaurant addRestaurant(Restaurant restaurant);
    Restaurant updateRestaurant(int id, Restaurant restaurant) throws RestaurantNotFoundException;
    String deleteRestaurant(int id) throws RestaurantNotFoundException;
    Restaurant getRestaurantByName(String name);
    Restaurant getRestaurantById(int id) throws RestaurantNotFoundException;
    List<Restaurant> getAllRestaurants();
}
