package com.Customer.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Customer.DTO.customerLogin;
import com.Customer.Exception.CustomerNotFoundException;
import com.Customer.entity.Customer;
import com.Customer.serviceImpl.CustomerServiceImplementation;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	   @Autowired
	    private CustomerServiceImplementation customerServiceImpl;
	 
	    // Register a new customer
	    @PostMapping("/register")
	    public Customer addCustomer(@RequestBody Customer customer) {
	        return customerServiceImpl.registerCustomer(customer);
	    }
	 
	    // Login customer and return token + username
	    @PostMapping("/login")
	    public ResponseEntity<Map<String, String>> loginCustomer(@RequestBody customerLogin customer) throws CustomerNotFoundException {
	        // Call the verify method to authenticate and get token
			Map<String, String> response = customerServiceImpl.verify(customer);
			return ResponseEntity.ok(response); // Return token and username in response
	    }
	 
	    // Get all customers
	    @GetMapping("/all")
	    public List<Customer> readAllCustomers() {
	        return customerServiceImpl.readAllCustomers();
	    }
	 
	    // Update customer details
	    @PutMapping("/update/{id}")
	    public String updateCustomer(@PathVariable(value = "id") int id, @RequestBody Customer customer) {
	        return customerServiceImpl.updateCustomer(id, customer);
	    }
	 
	    // Delete customer by ID
	    @DeleteMapping("/delete/{id}")
	    public String deleteCustomer(@PathVariable(value = "id") int id) {
	        return customerServiceImpl.deleteCustomer(id);
	    }
	 
	    // Get customer by email
	    @GetMapping("/byEmail/{email}")
	    public List<Customer> getCustomerByEmail(@PathVariable(value = "email") String email) throws CustomerNotFoundException {
	        return customerServiceImpl.getByEmail(email);
	    }
	 
	    // Get customer by ID
	    @GetMapping("/byId/{id}")
	    public Customer getCustomerById(@PathVariable(value = "id") int id) throws CustomerNotFoundException {
	        return customerServiceImpl.getCustomerById(id);
	    }
	    
	    @GetMapping("/byUsername/{username}")
	    public ResponseEntity<Customer> getCustomerByUsername(@PathVariable(value = "username") String username) throws CustomerNotFoundException {
	        Customer customer = customerServiceImpl.getCustomerByUsername(username); // Call service method to get customer by username
	        if (customer != null) {
	            return ResponseEntity.ok(customer);  // Return the customer details if found
	        } else {
	            throw new CustomerNotFoundException("Customer with username " + username + " not found");
	        }
	    }
	 
	}