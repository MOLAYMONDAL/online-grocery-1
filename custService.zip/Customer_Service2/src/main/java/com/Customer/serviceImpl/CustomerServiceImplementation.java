//package com.Customer.serviceImpl;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.Customer.DTO.customerLogin;
//import com.Customer.Exception.CustomerNotFoundException;
//import com.Customer.Repositary.CustomerRepository;
//import com.Customer.Service.CustomerService;
//import com.Customer.entity.Customer;
//import com.Customer.utils.jwtService;
//
//@Service
//public class CustomerServiceImplementation implements CustomerService {
//    
//    @Autowired
//    private AuthenticationManager auth;
//
//    @Autowired
//    private CustomerRepository customerRepository;
//
//    @Override
//    public Customer registerCustomer(Customer customer) {
//        BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder(12);
//        customer.setPassword(bcrypt.encode(customer.getPassword()));
//        return customerRepository.save(customer);
//    }
//
//
//    @Override
//    public List<Customer> readAllCustomers() {
//        return customerRepository.findAll();
//    }
//
//    @Override
//    public String updateCustomer(int id, Customer customer) {
//        try {
//            Customer existingCustomer = customerRepository.findById(id).orElseThrow(() -> new CustomerNotFoundException());
//            if (customer.getUsername() != null) existingCustomer.setUsername(customer.getUsername());
//            if (customer.getNumber() != 0) existingCustomer.setNumber(customer.getNumber());
//            if (customer.getAddress() != null) existingCustomer.setAddress(customer.getAddress());
//            if (customer.getEmail() != null) existingCustomer.setEmail(customer.getEmail());
//            customerRepository.save(existingCustomer);
//        } catch (CustomerNotFoundException e) {
//            return "Invalid customer.Customer data not updated";
//        }
//        return "Customer Updated Successfully";
//    }
//
//    @Override
//    public String deleteCustomer(int customerId) {
//        try {
//            customerRepository.findById(customerId).orElseThrow(() -> new CustomerNotFoundException());
//            customerRepository.deleteById(customerId);
//        } catch (CustomerNotFoundException e) {
//            return "Invalid customer id";
//        }
//        return "Customer deleted successfully.";
//    }
//
//    @Override
//    public Customer getCustomerById(int customerId) throws CustomerNotFoundException {
//        return customerRepository.findById(customerId).orElseThrow(() -> new CustomerNotFoundException("Invalid customer ID"));
//    }
//
//    @Override
//    public Map<String, String> verify(customerLogin customer) throws CustomerNotFoundException {
//        try {
//            // Attempt to authenticate the user
//            Authentication authenticate = auth.authenticate(
//                new UsernamePasswordAuthenticationToken(customer.getUsername(), customer.getPassword())
//            );
//
//            // If authenticated successfully, generate JWT token and return the username and token
//            if (authenticate.isAuthenticated()) {
//                String token = jwtService.generateToken(customer.getUsername());
//                Map<String, String> response = new HashMap<>();
//                response.put("username", customer.getUsername());
//                response.put("token", token);
//                return response;
//            }
//        } catch (Exception e) {
//            // If authentication fails or any other exception occurs, throw the CustomerNotFoundException
//            throw new CustomerNotFoundException("Invalid username or password.");
//        }
//
//        // Return null should never be reached because of exception handling, but added for safety
//        return null;
//    }
//
//
//	@Override
//	public List<Customer> getByEmail(String email) throws CustomerNotFoundException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	
//	@Override
//	public Customer getCustomerByUsername(String username) throws CustomerNotFoundException {
//	    return customerRepository.findByUsername(username)
//	            .orElseThrow(() -> new CustomerNotFoundException("Customer with username " + username + " not found"));
//	}
//
//
//
//}
 
package com.Customer.serviceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.Customer.DTO.customerLogin;
import com.Customer.Exception.CustomerNotFoundException;
import com.Customer.Exception.DuplicateCustomerException; // Custom exception for duplicate entries
import com.Customer.Repositary.CustomerRepository;
import com.Customer.Service.CustomerService;
import com.Customer.entity.Customer;
import com.Customer.utils.jwtService;

@Service
public class CustomerServiceImplementation implements CustomerService {
    
    @Autowired
    private AuthenticationManager auth;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private jwtService jwtService;

    @Override
    public Customer registerCustomer(Customer customer) {
        // Check if a customer with the same email or phone number already exists
        Optional<Customer> existingCustomerByEmail = customerRepository.findByEmail(customer.getEmail());
        if (existingCustomerByEmail.isPresent()) {
            throw new DuplicateCustomerException("Email is already registered.");
        }

        Optional<Customer> existingCustomerByNumber = customerRepository.findByNumber(customer.getNumber());
        if (existingCustomerByNumber.isPresent()) {
            throw new DuplicateCustomerException("Phone number is already registered.");
        }

        // Encrypt the password
        BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder(12);
        customer.setPassword(bcrypt.encode(customer.getPassword()));
        return customerRepository.save(customer);
    }

    @Override
    public List<Customer> readAllCustomers() {
        return customerRepository.findAll();
    }

    @Override
    public String updateCustomer(int id, Customer customer) {
        try {
            Customer existingCustomer = customerRepository.findById(id)
                    .orElseThrow(() -> new CustomerNotFoundException());

            if (customer.getUsername() != null) existingCustomer.setUsername(customer.getUsername());
            if (customer.getNumber() != 0) existingCustomer.setNumber(customer.getNumber());
            if (customer.getAddress() != null) existingCustomer.setAddress(customer.getAddress());
            if (customer.getEmail() != null) existingCustomer.setEmail(customer.getEmail());
            
            customerRepository.save(existingCustomer);
        } catch (CustomerNotFoundException e) {
            return "Invalid customer. Customer data not updated.";
        }
        return "Customer updated successfully.";
    }

    @Override
    public String deleteCustomer(int customerId) {
        try {
            customerRepository.findById(customerId)
                    .orElseThrow(() -> new CustomerNotFoundException());
            customerRepository.deleteById(customerId);
        } catch (CustomerNotFoundException e) {
            return "Invalid customer ID.";
        }
        return "Customer deleted successfully.";
    }

    @Override
    public Customer getCustomerById(int customerId) throws CustomerNotFoundException {
        return customerRepository.findById(customerId)
                .orElseThrow(() -> new CustomerNotFoundException("Invalid customer ID."));
    }

    @Override
    public Map<String, String> verify(customerLogin customer) throws CustomerNotFoundException {
        try {
            // Authenticate the customer
            Authentication authenticate = auth.authenticate(
                    new UsernamePasswordAuthenticationToken(customer.getUsername(), customer.getPassword())
            );

            // Generate JWT token if authentication is successful
            if (authenticate.isAuthenticated()) {
                String token = jwtService.generateToken(customer.getUsername());
                Map<String, String> response = new HashMap<>();
                response.put("username", customer.getUsername());
                response.put("token", token);
                return response;
            }
        } catch (Exception e) {
            throw new CustomerNotFoundException("Invalid username or password.");
        }

        return null; // Unreachable due to exception handling, added for safety
    }

    @Override
    public List<Customer> getByEmail(String email) throws CustomerNotFoundException {
        // TODO: Implement this method to retrieve customers by email
        return null;
    }

    @Override
    public Customer getCustomerByUsername(String username) throws CustomerNotFoundException {
        return customerRepository.findByUsername(username)
                .orElseThrow(() -> new CustomerNotFoundException("Customer with username " + username + " not found."));
    }
}
