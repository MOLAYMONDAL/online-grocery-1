package com.Customer.entity;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

public class MyUserDetails implements UserDetails {
    private String username;
    private String password;
    private Collection<? extends GrantedAuthority> authorities;

    public MyUserDetails(Customer customer) {
        this.username = customer.getUsername();
        this.password = customer.getPassword();
        // Example: Set authorities based on roles if needed
        this.authorities = Collections.emptyList(); // Default empty list; adjust as needed
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Adjust based on your needs
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Adjust based on your needs
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Adjust based on your needs
    }

    @Override
    public boolean isEnabled() {
        return true; // Adjust based on your needs
    }
}
