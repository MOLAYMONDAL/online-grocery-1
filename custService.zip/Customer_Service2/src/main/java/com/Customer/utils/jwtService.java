package com.Customer.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
@Component
public class jwtService {

	public static String generateToken(String username) {
		// TODO Auto-generated method stub
		Map <String,Object> claim=new HashMap<>();
		return Jwts.builder()
				.claims()
				.add( claim)
				.subject(username)
				.issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis()+(1000*60*60)))
				.and()
				.signWith(jwtSign())
				.compact();
	}

	private static SecretKey jwtSign() {
		// TODO Auto-generated method stub
		String sign="ddfhsdiuf@dsifue78r7e876r2t376tr72r6@TY@EREeeRAEsradt4dtayzd65e6ff6wefes7fe5S@eqdtsadhe897w988&&*%ksdiusdiufydsy";

		return Keys.hmacShaKeyFor(sign.getBytes());
	}

	public  String extractUserName(String token) {
		// TODO Auto-generated method stub
		return extactAllClaims(token).getSubject();
	}
	public Claims extactAllClaims(String token) {
		return Jwts.parser()
				.verifyWith(jwtSign())
				.build()
				.parseSignedClaims(token)
				.getPayload();}

	public  boolean validateToken(String token, UserDetails user) {
		// TODO Auto-generated method 
		String name=extractUserName(token);
		return (name.equals(user.getUsername())) ;
	}
}
