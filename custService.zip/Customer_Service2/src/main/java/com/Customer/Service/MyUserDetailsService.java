package com.Customer.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Customer.Repositary.CustomerRepository;
import com.Customer.entity.Customer;
import com.Customer.entity.MyUserDetails;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private CustomerRepository customerRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Customer> customerOptional = customerRepo.findByUsername(username);
        
        // Handle the case where the Customer is not found
        Customer customer = customerOptional.orElseThrow(() -> 
            new UsernameNotFoundException("User not found with username: " + username)
        );
        
        // Return the MyUserDetails object
        return new MyUserDetails(customer);
    }
}
