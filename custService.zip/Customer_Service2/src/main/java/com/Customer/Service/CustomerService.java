package com.Customer.Service;

import java.util.List;
import java.util.Map;

import com.Customer.DTO.customerLogin;
import com.Customer.Exception.CustomerNotFoundException;
import com.Customer.entity.Customer;


public interface CustomerService {

	public Customer registerCustomer(Customer customer);

	public String updateCustomer(int id, Customer customer);

	public String deleteCustomer(int id);

	public List<Customer> getByEmail(String email) throws CustomerNotFoundException;

	public Customer getCustomerById(int id) throws CustomerNotFoundException;
	
	public List<Customer> readAllCustomers();

	public Map<String, String> verify(customerLogin loginDetails) throws CustomerNotFoundException;
	
	public Customer getCustomerByUsername(String username) throws CustomerNotFoundException;
}
