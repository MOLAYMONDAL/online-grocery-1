package com.cg.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.CartDTO;
import com.cg.entity.Cart;
import com.cg.exception.AddToCartNotFoundException;
import com.cg.repository.CartRepository;
import com.cg.service.CartService;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Override
    public CartDTO addItemToCart(CartDTO cartDTO) {
        Cart cart = new Cart();
        cart.setCustomerId(cartDTO.getCustomerId());
        cart.setName(cartDTO.getName());
        cart.setPrice(cartDTO.getPrice());
        cart.setQuantity(cartDTO.getQuantity());
        Cart savedCart = cartRepository.save(cart);
        cartDTO.setId(savedCart.getId());
        return cartDTO;
    }

    @Override
    public CartDTO updateCartItem(Integer id, int quantity) throws AddToCartNotFoundException {
        Cart cartItem = cartRepository.findById(id)
                .orElseThrow(() -> new AddToCartNotFoundException("Item not found in cart"));
        cartItem.setQuantity(quantity);
        Cart updatedCart = cartRepository.save(cartItem);
        CartDTO cartDTO = new CartDTO();
        cartDTO.setId(updatedCart.getId());
        cartDTO.setName(updatedCart.getName());
        cartDTO.setPrice(updatedCart.getPrice());
        cartDTO.setQuantity(updatedCart.getQuantity());
        cartDTO.setCustomerId(updatedCart.getCustomerId());
        return cartDTO;
    }

    @Override
    public void removeItemFromCart(Integer id) {
        if (cartRepository.existsById(id)) {
            cartRepository.deleteById(id);
        } 
    }

    @Override
    public List<CartDTO> getCartItemsByCustomerId(Integer customerId) {
        List<Cart> cartItems = cartRepository.findByCustomerId(customerId);
        return cartItems.stream().map(cart -> {
            CartDTO cartDTO = new CartDTO();
            cartDTO.setId(cart.getId());
            cartDTO.setName(cart.getName());
            cartDTO.setPrice(cart.getPrice());
            cartDTO.setQuantity(cart.getQuantity());
            cartDTO.setCustomerId(cart.getCustomerId());
            return cartDTO;
        }).toList();
    }

    @Override
    public void clearCart(Integer customerId) {
        List<Cart> cartItems = cartRepository.findByCustomerId(customerId);
        cartRepository.deleteAll(cartItems);
    }
}
