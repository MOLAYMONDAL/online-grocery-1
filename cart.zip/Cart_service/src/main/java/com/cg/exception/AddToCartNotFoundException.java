package com.cg.exception;

public class AddToCartNotFoundException extends RuntimeException {
    public AddToCartNotFoundException(String message) {
        super(message);
    }
}
