package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cg.dto.CartDTO;
import com.cg.exception.AddToCartNotFoundException;
import com.cg.service.CartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin(origins = "http://localhost:3000/")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public ResponseEntity<CartDTO> addItemToCart(@RequestBody CartDTO cartDTO) {
        try {
            CartDTO addedCartItem = cartService.addItemToCart(cartDTO);
            return new ResponseEntity<>(addedCartItem, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<CartDTO> updateCartItem(@PathVariable Integer id, @RequestParam int quantity) {
        try {
            CartDTO updatedCartItem = cartService.updateCartItem(id, quantity);
            return new ResponseEntity<>(updatedCartItem, HttpStatus.OK);
        } catch (AddToCartNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<HttpStatus> removeItemFromCart(@PathVariable Integer id) {
        try {
            cartService.removeItemFromCart(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<CartDTO>> getCartItemsByCustomerId(@PathVariable Integer customerId) {
        try {
            List<CartDTO> cartItems = cartService.getCartItemsByCustomerId(customerId);
            return new ResponseEntity<>(cartItems, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/clear/{customerId}")
    public ResponseEntity<HttpStatus> clearCart(@PathVariable Integer customerId) {
        try {
            cartService.clearCart(customerId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
