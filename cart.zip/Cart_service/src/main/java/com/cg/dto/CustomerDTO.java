package com.cg.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {

	private int customerId;
	
	private String username;
	
	private String password;
	
	private String email;
	
	private long number;

	private String address;
}