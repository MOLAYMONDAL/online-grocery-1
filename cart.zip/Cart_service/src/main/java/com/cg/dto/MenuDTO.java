package com.cg.dto;

import lombok.Data;

@Data
public class MenuDTO {
	
	private int MenuId;
	
	private String MenuName;
	
	private int restaurantId;
   
    private String description;
	
	private double MenuPrice;
	
}