package com.cg.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class CartDTO {

	    private Integer id;    
	    private Integer customerId;
	    private String name;      
	    private double price;     
	    private int quantity;    
	  
} 