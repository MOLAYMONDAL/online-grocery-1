package com.cg.service;

import java.util.List;

import com.cg.dto.CartDTO;
import com.cg.exception.AddToCartNotFoundException;

public interface CartService {
	

  
	 CartDTO addItemToCart(CartDTO cartDTO);

   
	 CartDTO updateCartItem(Integer id, int quantity) throws AddToCartNotFoundException;

  
	 void removeItemFromCart(Integer id);

   
    List<CartDTO> getCartItemsByCustomerId(Integer customerId);

   
     void clearCart(Integer customerId);
}
