package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.dto.CustomerDTO;
import com.cg.exception.CustomerNotFoundException;


@FeignClient(name = "Customer-Service")
public interface CustomerService {
    @GetMapping("/customers/byId/{id}")
    CustomerDTO getCustomerById(@PathVariable("id") int id) throws CustomerNotFoundException;
}

