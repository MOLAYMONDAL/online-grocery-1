package com.Menu.service;

import java.util.List;

import com.Menu.entity.Menu;
import com.Menu.exception.MenuNotFoundException;
import com.Menu.exception.NoSuchRestaurantException;

public interface MenuService {
    Menu getById(int menuId) throws MenuNotFoundException;
    Menu updateMenu(int menuId, Menu menu) throws MenuNotFoundException;
    String deleteMenu(int menuId);
    Menu addMenu(Menu menu) throws NoSuchRestaurantException;
    List<Menu> getAllMenu();
    List<Menu> getByRestaurantId(int restaurantId) throws NoSuchRestaurantException;
}
