package com.Menu.dto;


import lombok.Data;

@Data
public class RestaurantDTO {

	private int restaurantId;       
    private String name;            
    private String address;         
    private String cuisineType; 
}
