package com.Menu.exception;


public class NoSuchRestaurantException extends Exception{
	
	public NoSuchRestaurantException(String msg) {
		super(msg);
		}

}
