package com.Menu.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Menu.entity.Menu;

@Repository
public interface MenuRepository extends JpaRepository<Menu,Integer>{


	public List<Menu> findByRestaurantId(int restaurantId);
}
