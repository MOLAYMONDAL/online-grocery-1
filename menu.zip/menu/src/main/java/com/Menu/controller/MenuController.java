package com.Menu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Menu.client.RestaurantService;
import com.Menu.dto.RestaurantDTO;
import com.Menu.entity.Menu;
import com.Menu.exception.MenuNotFoundException;
import com.Menu.exception.NoSuchRestaurantException;
import com.Menu.service.MenuService;

@RestController
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;
    
    @Autowired
    private RestaurantService restaurantService;

    // Endpoint to add a new menu
    @PostMapping("/add")
    public Menu addMenu(@RequestBody Menu menu) throws NoSuchRestaurantException {
        return menuService.addMenu(menu);
    }

    // Endpoint to retrieve a menu by its ID
    @GetMapping("/getById/{id}")
    public Menu getMenuById(@PathVariable(value = "id") int id) throws MenuNotFoundException {
        return menuService.getById(id);
    }

    // Endpoint to update a menu
    @PutMapping("/updateMenu/{id}")
    public Menu updateMenu(@PathVariable(value = "id") int id, @RequestBody Menu menu) throws MenuNotFoundException {
        return menuService.updateMenu(id, menu);
    }

    // Endpoint to delete a menu by its ID
    @DeleteMapping("/deleteMenu/{id}")
    public String deleteMenu(@PathVariable(value = "id") int id) {
        return menuService.deleteMenu(id);
    }

    // Endpoint to retrieve all menus
    @GetMapping("/getAllMenu")
    public List<Menu> getAllMenus() {
        return menuService.getAllMenu();
    }

    // Endpoint to retrieve menus by restaurant ID
    @GetMapping("/getByRestaurantId/{id}")
    public List<Menu> getMenusByRestaurantId(@PathVariable(value = "id") int id) throws NoSuchRestaurantException {
        return menuService.getByRestaurantId(id);
    }
    
    @GetMapping("/{restaurantId}")
    public RestaurantDTO getRestaurantById(@PathVariable int restaurantId) {
        return restaurantService.getRestaurantById(restaurantId);
    }
}
